import xbmcaddon

MainBase = 'https://ia601509.us.archive.org/14/items/playmovie_Ltd/home.txt'
addon = xbmcaddon.Addon('plugin.video.PlayMovie')